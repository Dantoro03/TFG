<?php 

$info = '2';
if (isset($_GET['id'])){
    $info = $_GET['id'];
}

if (isset($_GET['selection'])){
    $id_pl = $_GET['selection'];
}

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
$file = 'playlists/'.$id_pl.'.xlsx';

$spreadsheet = IOFactory::load($file);

$hoja = $spreadsheet->getActiveSheet();

$pos = $hoja->getCell('A'.$info)->getValue();
$name = $hoja->getCell('B'.$info)->getValue();
$art = $hoja->getCell('C'.$info)->getValue();
$album = $hoja->getCell('E'.$info)->getValue();
$single = $hoja->getCell('F'.$info)->getValue();
$rel = $hoja->getCell('G'.$info)->getValue();
$pop = $hoja->getCell('I'.$info)->getValue();
$dif = $hoja->getCell('H'.$info)->getValue();
$val = ($hoja->getCell('T'.$info)->getValue()*100);
$BPM = $hoja->getCell('U'.$info)->getValue();
$loud = $hoja->getCell('N'.$info)->getValue();
$dance = ($hoja->getCell('K'.$info)->getValue()*100);
$energy = ($hoja->getCell('L'.$info)->getValue()*100);
$speech = ($hoja->getCell('P'.$info)->getValue()*100);
$inst = ($hoja->getCell('R'.$info)->getValue()*100);
$acous = ($hoja->getCell('Q'.$info)->getValue()*100);
$live = ($hoja->getCell('S'.$info)->getValue()*100);
$mode = $hoja->getCell('O'.$info)->getValue();
$key = $hoja->getCell('M'.$info)->getValue();
$sign = $hoja->getCell('AB'.$info)->getValue();
$time = floor($hoja->getCell('AA'.$info)->getValue() / 1000);
$min = floor($time / 60);
$sec = $time % 60;
$time = sprintf("%02d:%02d", $min, $sec);

switch ($key) {
    case -1:
        $key = "Nota no válida";
        break;
    case 0:
        $key = "C";
        break;
    case 1:
        $key = "C#";
        break;
    case 2:
        $key = "D";
        break;
    case 3:
        $key = "D#";
        break;
    case 4:
        $key = "E";
        break;
    case 5:
        $key = "F";
        break;
    case 6:
        $key = "F#";
        break;
    case 7:
        $key = "G";
        break;
    case 8:
        $key = "G#";
        break;
    case 9:
        $key = "A";
        break;
    case 10:
        $key = "A#";
        break;
    case 11:
        $key = "B";
        break;
    default:
        $key = "Nota no válida";
}
switch ($mode) {
    case 0:
        $mode = "m";
        break;
    case 1:
        $mode = "M";
        break;
    }
?>

        <div class="row align-items-center">
            <div class="col-md-6 imagen-cont">
                <img class="img-thumbnail p-0" id="imagen" src="<?php echo $hoja->getCell('J'.$info)->getValue() ?>" alt="album_cover"> 
            </div> 
            <div class="col-md-6" id="info1texto">
                <div class="row">
                    <div class="col-md-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-play"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg></div>
                    <p class="col-md-10"><?php echo $name; ?></p> 
                </div>
                <div class="row">
                    <div class="col-md-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>
                    <p class="col-md-10"><?php echo $art; ?></p>
                </div>
                <div class="row">
                    <div class="col-md-2"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-disc"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg> </div>
                    <?php if ($single == "single"): ?>
                        <p class="col-md-10">Single</p>
                    <?php else: ?>
                        <p class="col-md-10"><?php echo $album; ?></p>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-2"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div>
                    <p class="col-md-10"><?php echo $time; ?>m</p>
                </div>
                <div class="row">
                <div class="col-md-2"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> </div>
                    <p class="col-md-10"> <?php echo $rel; ?></p>
                </div>
                <div class="row">
                <div class="col-md-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-music"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg></div>
                    <p class="col-md-10"> <?php echo $key, $mode . " 4/". $sign ?></p>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-md-6">
                <canvas id="myChart"><?php echo $dance . ";" . $energy . ";" . $speech . ";" . $inst . ";" . $val . ";" . $acous . ";" . $live; ?></canvas>
            </div>
            <div class="col-md-6 sound-bars">
                <?php
                $num_total = 14;
                if ($loud <= -20){
                    $num_encendidas = 0;
                }else{
                    $num_encendidas = 14-(($loud / -20) * 14);
                }
                $opacidad_dB = 0.3;
                for ($i = 0; $i < $num_total; $i++) {
                    $opacidad = $i > $num_encendidas ? $opacidad_dB : 1;
                    switch ($i) {
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                            $clase = 'bar-v';
                            break;
                        case 6:
                        case 7:
                        case 8:
                        case 9:
                        case 10:
                            $clase = 'bar-a';
                            break;
                        default:
                            $clase = 'bar-r';
                            break;
                    }
                    echo "<div class='$clase' style='opacity: $opacidad'></div>";
                }
                ?>
                <p class="text-center"><?php echo $loud; ?> dB<p>
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        $num_barrasbpm = 14;
                        $num_apagadas_bpm = ($BPM / 200) * 14;
                        $opacidad_bpm = 0.3;
                        for ($i = 0; $i < $num_barrasbpm; $i++) {
                            $opacidad_adicional = $i > $num_apagadas_bpm ? $opacidad_bpm : 1;
                            switch ($i) {
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                    $clase_adicional = 'bar-v';
                                    break;
                                case 6:
                                case 7:
                                case 8:
                                case 9:
                                case 10:
                                    $clase_adicional = 'bar-a';
                                    break;
                                default:
                                    $clase_adicional = 'bar-r';
                                    break;

                            }
                            echo "<div class='$clase_adicional' style='opacity: $opacidad_adicional'></div>";
                        }
                        ?>
                        <p class="text-center"><?php echo intval($BPM);?> BPM</p>
                    </div>
                </div>
            </div>
        </div>

