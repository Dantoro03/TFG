
    <div>
    <img id="imagen" src="<?php echo $hoja->getCell('K'.'2')->getValue() ?>" alt="album_cover">
    <div class="text text-white">
    <?php
    echo "<p> Posición:".$hoja->getCell('A'.'2')->getValue()." </p>
    <p> Nombre: ".$hoja->getCell('B'.'2')->getValue()."</p>
    <p> Artista: ".$hoja->getCell('D'.'2')->getValue()."</p>
    <p> Album: ".$hoja->getCell('F'.'2')->getValue()."</p>
    <p> Popularity: ".$hoja->getCell('J'.'2')->getValue()."</p>"
    ?>
    </div>
</div>