<?php  
    //ID LA ID DE LA CANCIÓN
    //SELECTION LA ID DE LA PLAYLIST
    if (isset($_GET['id'])) {
        include __DIR__. '/loadinfo.php';
    }elseif (isset($_GET['selection'])) {
        include __DIR__. '/container.php';
    }else{
        include __DIR__. '/landing.php';
    }

?>

