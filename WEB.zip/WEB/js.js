const APIController = (function() {

    const clientId = '3f8ef9ff42d44b359a0adbe3d2b13d9c'
    const clientSecret = '0623af06d41e48cd8fb6e64de029ede3'

    const _getToken = async () => {

        const result = await fetch(`https://accounts.spotify.com/api/token`,{
            method: 'POST',
            headers: {
                'Content-type' : 'application/x-www-form-urlencoded',
                'Autorization' : 'Basic' + btoa( clientId + ':' + clientSecret)
            },
            body: 'grant_type=client_credentials'
        });

        const data = await result.json();
        return data.acces_token;
    }

    const _getGenres = async (token) => {

        const result = await fetch(`https://api.spotify.com/v1/browse/categories?locale=sv_US`, {
            method: 'GET',
            headers: {'Autorization' : 'Bearer ' + token }
        });

        const data = await result.json();
        return data.categories.items;
    }

    const _getPlaylistByGenre = async (token, genreId) => {
        const limit = 10;

        const result = await fetch(`https://api.spotify.com/v1/browse/categories/${genreId}/playlists?limit=${limit}`,{
            method: 'GET',
            headers: {'Autorization' : 'Bearer ' + token}
        });

        const data = await result.json();
        return data.playlist.items;
    }

    const _getTracks = async (token, tracksEndPoint) => {

        const limit = 10;

        const result = await fetch(`${tracksEndPoint}?limit=${limit}`, {
            method: 'GET',
            headers: {'Autorization' : 'Bearer ' + token}
        });

        const data = await result.json();
        return data.items;
    }
