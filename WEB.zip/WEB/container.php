<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

if (isset($_GET['selection'])){
    $id_pl = $_GET['selection'];
    
}
else {
    $id_pl = $pl_hoja->getCell('A3')->getValue();
}
if (isset($_GET['name'])){
    $name_country = $_GET['name'];
    
}
else {
    $name_country = $pl_hoja->getCell('B3')->getValue();
}

    $file = 'playlists/'.$id_pl.'.xlsx';

    $spreadsheet = IOFactory::load($file);

    $hoja = $spreadsheet->getActiveSheet();

    $numFilas = $hoja->getHighestRow();

?>
<div class="row text-center align-middle">
    <h1 class="titulo text-white"> <?php echo $name_country ?> </h1>
</div>
<div class="row">
    <div class="container h-100 col-md-5">
        <div class="row pl-repro mb-2">
        <?php echo '<iframe style="border-radius:12px" src="https://open.spotify.com/embed/playlist/'.$id_pl.'?utm_source=generator&theme=0" width="100%" height="152" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>'?>
    </div>
    <div class="row repro d-grid gap-2">       
    <?php
        for ($i=2; $i <= $numFilas ; $i++) { 
            $cover = $hoja->getCell('J' . $i)->getValue();
            $nombre = $hoja->getCell('B' . $i)->getValue();
            $artista = $hoja->getCell('C' . $i)->getValue();
            $pos = $i - 1;
            echo " 
            <div class='contenedor-reproductor container w-100 text-white'>
            <div class='pos my-2'>".$pos."</div>
            <div class='row'>
                <div class='image-container col-2'>
                    <img class='m-1 p-0 img-thumbnail' src='$cover'>
                </div>
                <div class='container mt-1 pe-0 col-8'>
                    <div class='row'>
                        <div class='text-truncate' >$nombre</div>
                    </div>
                    <div class='row'>
                    <div class='text-truncate' >$artista</div>
                </div>
            </div>
            <div class='container col-1 ps-0 my-2'>
            <button class='info-boton' onclick='changeinfo(".$i.", \"".$id_pl."\")'>i</button>
            </div>
        </div> 
        </div>"; 
        ;
        } 
    ?>
    </div>
    </div>
    <div id="infocontent" class="contenedor col-md-7 pt-4 pb-0 mb-2">
        <?php include __DIR__. '/loadinfo.php'; ?>
    </div>
</div>
</div>