// Definir la información de las canciones
const canciones = [
  {
    titulo: "Canción 1",
    informacion: "Información de la Canción 1..."
  },
  {
    titulo: "Canción 2",
    informacion: "Información de la Canción 2..."
  }
];

// Función para mostrar la información de la canción seleccionada
function mostrarCancion(index) {
  const cancionSeleccionada = canciones[index - 1]; // Restar 1 porque los índices comienzan desde 0
  const informacionCancionElement = document.getElementById("informacion-cancion");
  informacionCancionElement.innerHTML = `
    <h2>${cancionSeleccionada.titulo}</h2>
    <p>${cancionSeleccionada.informacion}</p>
  `;
}
